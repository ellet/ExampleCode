﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public enum InputModes
{
    MoveDuder,
    SetTileType
}

public class PlayerDuder : MonoBehaviour
{
    // Update is called once per frame

    //public TileManager TileManager;
    //public float PlayerMoveSpeed = 50.0f;
    //public float GoalReachedDistance = 0.1f;

    //public Vector2 myGoalPosition;
    //private Vector2 myNextPosition;
    //private bool myMoveTowardsGoal = false;
    //public InputModes myInputMode = InputModes.MoveDuder;
    
    //public EventSystem EventsHandler;

    public void OnInputButtonChangedClicked()
    {
        //if (myInputMode == InputModes.MoveDuder)
        //{
        //    myInputMode = InputModes.SetTileType;
        //    TileManager.TurnOnTileGUI();
        //}
        //else
        //{
        //    myInputMode = InputModes.MoveDuder;
        //    TileManager.TurnOffTileGUI();
        //}
    }

    void Update()
    {
        //CheckInput();

        //if (myMoveTowardsGoal == true)
        //{
        //    Vector2 moveTowardsPoint = myNextPosition;
        //    if (TileManager.IsTileEndTile(transform.position))
        //    {
        //        moveTowardsPoint = myGoalPosition;
        //    }

        //    MoveTowardsPosition(moveTowardsPoint);
        //    CheckIfReachedTarget(moveTowardsPoint);
        //}
    }

    private void CheckInput()
    {
        //if (EventsHandler.IsPointerOverGameObject())
        //    return;

        //if (Input.GetButtonDown("Fire1") && myInputMode == InputModes.MoveDuder)
        //{
        //    myGoalPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //    TileManager.GenerateDjikstrasMap(myGoalPosition);
        //    myNextPosition = TileManager.GetCheapestTilePositionFromPosition(transform.position);

        //    myMoveTowardsGoal = true;
        //}
        //if (Input.GetButton("Fire1") && myInputMode == InputModes.SetTileType)
        //{
        //    TileManager.HandleInput();
        //}
    }

    private void MoveTowardsPosition(Vector2 aMoveTowardsPosition)
    {
        //float tileCost = TileManager.GetTileCost(transform.position);
        //Vector2 GoalDirection = (aMoveTowardsPosition - (Vector2)transform.position).normalized;
        //Vector2 MoveDelta = GoalDirection * Time.deltaTime * (PlayerMoveSpeed / tileCost);

        //Vector3 newPosition = transform.position + (Vector3)MoveDelta;
        //if (TileManager.IsTileWalkable(newPosition))
        //{
        //    transform.position = newPosition;
        //}
    }

    private void CheckIfReachedTarget(Vector2 aMoveTowardsPosition)
    {
        //float DistanceToTarget = (aMoveTowardsPosition - (Vector2)transform.position).magnitude;

        //if (DistanceToTarget <= GoalReachedDistance)
        //{
        //    if (TileManager.IsTileEndTile(transform.position))
        //    {
        //        myMoveTowardsGoal = false;
        //    }
        //    else
        //    {
        //        myNextPosition = TileManager.GetCheapestTilePositionFromPosition(transform.position);
        //    }
        //}
    }
}