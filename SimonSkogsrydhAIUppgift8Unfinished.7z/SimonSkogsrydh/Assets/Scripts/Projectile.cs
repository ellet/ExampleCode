﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {

    private float myProjectileSpeed = 7.0f;
    private Vector2 myDirection;
    private AITeams myTeamAlliance;
    private float myCollisionSize = 0.45f;
    private float myDamageAmount = 17.0f;
    private float myLifeTimer = 0.0f;

    public void Go(AITeams aTeamAlliance, Vector2 aDirection)
    {
        myTeamAlliance = aTeamAlliance;
        myDirection = aDirection;
        //transform.rotation = Quaternion.LookRotation(myDirection);
    }
	
	// Update is called once per frame
	void Update()
    {
        Move();
        CollisionCheck();

        myLifeTimer += Time.deltaTime;
        if (myLifeTimer > 6.0f)
        {
            Destroy(gameObject);
        }
	}

    private void Move()
    {
        Vector2 MoveDelta = myDirection * myProjectileSpeed * Time.deltaTime;
        transform.position += (Vector3)MoveDelta;
    }

    private void CollisionCheck()
    {
        List<FighterAI> Enemies = PollingStation.GetInstance().GetOpposingTeam(myTeamAlliance);

        foreach (FighterAI Fighter in Enemies)
        {
            float DistanceToFighter = (Fighter.transform.position - transform.position).magnitude;
            if (DistanceToFighter < myCollisionSize)
            {
                Fighter.TakeDamage(myDamageAmount);
                Destroy(gameObject);
                break;
            }
        }
    }
}
