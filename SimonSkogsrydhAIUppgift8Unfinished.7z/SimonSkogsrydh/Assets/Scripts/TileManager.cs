﻿using Priority_Queue;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileManager : MonoBehaviour
{
    public GameObject TileObject = null;
    public Vector2Int TileMapSize = new Vector2Int(3, 3);
    public float TileSize = 1.0f;
    public ETerrainTypes CurrentTerrainType = ETerrainTypes.Road;
    public UnityEngine.UI.Dropdown TileTypeDropdown;
    public UnityEngine.UI.Dropdown InfluenceDropDown;
    public CanvasGroup TileEditingGUICanvasGroup;
    public UnityEngine.UI.Button InputChangeButton;
    public UnityEngine.UI.Button ShowDjikstrasButton;
    public GameObject DjikstrasDebbugerParent;
    public CanvasGroup DjikstrasDebuggerGroup;
    public Font TextFont;


    private List<GameObject> myTiles = new List<GameObject>();
    private TerrainData[] myTerrainTypes;

    // Use this for initialization
    void Start()
    {
        if (TileObject == null)
            return;

        CreateTileTypes();
        GenerateTiles();
        SetupTileConnections();
    }

    public void ToggleShowDjikstras()
    {
        DjikstrasDebuggerGroup.alpha = Mathf.Abs(DjikstrasDebuggerGroup.alpha -1.0f);
    }

    private bool myShowInfluence = false;
    public void ToggleInflunce()
    {
        myShowInfluence = !myShowInfluence;
    }

    private void Update()
    {
        foreach (GameObject tileObject in myTiles)
        {
            tileObject.GetComponent<TerrainTile>().SetDebugInfluenceState((TileLayers)InfluenceDropDown.value, myShowInfluence);
        }
    }

    private void CreateTileTypes()
    {
        myTerrainTypes = new TerrainData[(int)ETerrainTypes.MAX];
        myTerrainTypes[(int)ETerrainTypes.Grass].TileColor = Color.green;
        myTerrainTypes[(int)ETerrainTypes.Grass].TileCost = 2.0f;
        myTerrainTypes[(int)ETerrainTypes.Grass].Blocked = false;


        myTerrainTypes[(int)ETerrainTypes.Road].TileColor = Color.yellow;
        myTerrainTypes[(int)ETerrainTypes.Road].TileCost = 1.0f;
        myTerrainTypes[(int)ETerrainTypes.Road].Blocked = false;

        myTerrainTypes[(int)ETerrainTypes.Mountain].TileColor = Color.grey;
        myTerrainTypes[(int)ETerrainTypes.Mountain].TileCost = 9999.0f;
        myTerrainTypes[(int)ETerrainTypes.Mountain].Blocked = true;

        myTerrainTypes[(int)ETerrainTypes.Swamp].TileColor = Color.cyan;
        myTerrainTypes[(int)ETerrainTypes.Swamp].TileCost = 5.0f;
        myTerrainTypes[(int)ETerrainTypes.Swamp].Blocked = false;

        TileTypeDropdown.options.Clear();
        TerrainTile.FontType = TextFont;
        foreach (ETerrainTypes TileType in System.Enum.GetValues(typeof(ETerrainTypes)))
        {
            if (TileType == ETerrainTypes.MAX)
                continue;

            UnityEngine.UI.Dropdown.OptionData newItem = new UnityEngine.UI.Dropdown.OptionData();

            newItem.text = TileType.ToString();

            TileTypeDropdown.options.Add(newItem);
        }

        TileTypeDropdown.value = (int)CurrentTerrainType;
        TileTypeDropdown.RefreshShownValue();
        TurnOffTileGUI();

        InfluenceDropDown.options.Clear();
        foreach (TileLayers InfluenceStuff in System.Enum.GetValues(typeof(TileLayers)))
        {
            UnityEngine.UI.Dropdown.OptionData newItem = new UnityEngine.UI.Dropdown.OptionData();

            newItem.text = InfluenceStuff.ToString();

            InfluenceDropDown.options.Add(newItem);
        }
        InfluenceDropDown.RefreshShownValue();
    }

    private void GenerateTiles()
    {
        transform.position = Vector3.zero;

        Vector2 Offset = (Vector2)TileMapSize / 2.0f;
        Offset.x -= TileSize / 2.0f;
        Offset.y -= TileSize / 2.0f;

        DjikstrasDebbugerParent.transform.position = transform.position;

        for (int iHeight = 0; iHeight < TileMapSize.y; iHeight++)
        {
            for (int iWidth = 0; iWidth < TileMapSize.x; iWidth++)
            {
                GameObject createdTile = Instantiate(TileObject, new Vector3(iWidth - Offset.x, iHeight - Offset.y, 0.0f), Quaternion.identity, transform);
                createdTile.GetComponent<TerrainTile>().SetTerrainData(myTerrainTypes[(int)ETerrainTypes.Grass]);
                createdTile.GetComponent<TerrainTile>().DebuggerParent = DjikstrasDebbugerParent;

                myTiles.Add(createdTile);
            }
        }
    }

    private void SetupTileConnections()
    {
        for (int iX = 0; iX < TileMapSize.x; iX++)
        {
            for (int iY = 0; iY < TileMapSize.y; iY++)
            {
                Vector2Int currentTilePosition = new Vector2Int(iX, iY);
                TerrainTile Tile = GetTileFromTilePosition(currentTilePosition);

                AddConnectionIfValid(Tile, currentTilePosition - Vector2Int.right);
                AddConnectionIfValid(Tile, currentTilePosition - Vector2Int.up);
                AddConnectionIfValid(Tile, currentTilePosition + Vector2Int.right);
                AddConnectionIfValid(Tile, currentTilePosition + Vector2Int.up);
            }
        }
    }

    public void ResetInflunce()
    {
        foreach (GameObject tileObject in myTiles)
        {
            TerrainTile Tile = tileObject.GetComponent<TerrainTile>();

            Tile.ResetTileInfluence();
        }
    }

    public bool IsTileEndTile(int aLayerIndex,Vector2 aWorldPosition)
    {
        TerrainTile tile = GetTileFromWorldPosition(aWorldPosition);

        return tile.IsEndTile(aLayerIndex);
    }

    public Vector2 GetCheapestTilePositionFromPosition(int aLayerIndex,Vector2 aWorldPosition)
    {
        TerrainTile tile = GetTileFromWorldPosition(aWorldPosition);

        return tile.GetCheapestConnection(aLayerIndex).transform.position;
    }

    public void GenerateDjikstrasMap(int aDjikstrasLayer, Vector2 aWorldPosition)
    {
        foreach (GameObject tileObject in myTiles)
        {
            tileObject.GetComponent<TerrainTile>().ResetTileCost(aDjikstrasLayer);
        }

        TerrainTile StartTile = GetTileFromWorldPosition(aWorldPosition);
        SimplePriorityQueue<TerrainTile> TilesToCheck = new SimplePriorityQueue<TerrainTile>();
        StartTile.SetAsStartTile(aDjikstrasLayer);
        TilesToCheck.Enqueue(StartTile, 0.0f);

        while (TilesToCheck.Count > 0)
        {
            TerrainTile TileToUpdate = TilesToCheck.Dequeue();
            TileToUpdate.UpdateConnectedTilesCost(aDjikstrasLayer, TilesToCheck);
        }
    }

    public void AddInfluence(AITeams aTileLayer, float aInflunceStartCost, Vector2 aWorldPosition)
    {
        TerrainTile StartTile = GetTileFromWorldPosition(aWorldPosition);
        List<TerrainTile> TilesAlreadyChecked = new List<TerrainTile>();
        SimplePriorityQueue<TiredSolution> TilesToCheck = new SimplePriorityQueue<TiredSolution>();

        TiredSolution soTired = new TiredSolution();
        soTired.Influence = aInflunceStartCost;
        soTired.Tile = StartTile;

        TilesToCheck.Enqueue(soTired, 0.0f);

        TileLayers Layer = TileLayers.BlueTeam;
        if (aTileLayer == AITeams.Reds)
        {
            Layer = TileLayers.RedTeam;
        }

        while (TilesToCheck.Count > 0)
        {
            TiredSolution DataToCheck = TilesToCheck.Dequeue();

            DataToCheck.Tile.AddTeamInfluence(Layer, DataToCheck.Influence, TilesToCheck, TilesAlreadyChecked);
        }
    }

    public void DebugLayer(int aDjisktrasLayer)
    {
        foreach (GameObject tileObject in myTiles)
        {
            tileObject.GetComponent<TerrainTile>().RefreshDebugCost(aDjisktrasLayer);
        }
    }

    private void AddConnectionIfValid(TerrainTile aTile, Vector2Int aTilePosition)
    {
        if (IsValidIndexPosition(aTilePosition))
        {
            aTile.AddConnection(GetTileFromTilePosition(aTilePosition));
        }
    }

    private bool IsValidIndexPosition(Vector2Int aTilePosition)
    {
        return aTilePosition.x >= 0 && aTilePosition.x < TileMapSize.x && aTilePosition.y >= 0 && aTilePosition.y < TileMapSize.y;
    }

    private TerrainTile GetTileFromTilePosition(Vector2Int aTilePosition)
    {
        int TileIndex = (aTilePosition.y * TileMapSize.x) + aTilePosition.x;
        return myTiles[TileIndex].GetComponent<TerrainTile>();
    }

    private TerrainTile GetTileFromWorldPosition(Vector2 aWorldPosition)
    {
        Vector2 Offset = (Vector2)TileMapSize / 2.0f;
        Vector2 positionWithOffset = aWorldPosition + Offset;
        int TileIndex = ((int)positionWithOffset.y * TileMapSize.x) + (int)positionWithOffset.x;
        return myTiles[TileIndex].GetComponent<TerrainTile>();
    }

    public void HandleInput()
    {
        Vector2 worldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        TerrainTile tile = GetTileFromWorldPosition(worldPosition);

        UpdateTileType();
        tile.SetTerrainData(myTerrainTypes[(int)CurrentTerrainType]);
    }

    public void TurnOnTileGUI()
    {
        TileEditingGUICanvasGroup.alpha = 1.0f;
        TileEditingGUICanvasGroup.blocksRaycasts = true;
        InputChangeButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "Movemode";
    }

    public void TurnOffTileGUI()
    {
        TileEditingGUICanvasGroup.alpha = 0.0f;
        TileEditingGUICanvasGroup.blocksRaycasts = false;
        InputChangeButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "EditMode";
    }

    private void UpdateTileType()
    {
        CurrentTerrainType = (ETerrainTypes)(TileTypeDropdown.value);
    }

    public float GetTileCost(Vector2 aWorldPosition)
    {
        TerrainTile tile = GetTileFromWorldPosition(aWorldPosition);

        return tile.GetCost();
    }

    public bool IsTileWalkable(Vector2 aWorldPosition)
    {
        TerrainTile tile = GetTileFromWorldPosition(aWorldPosition);

        return tile.IsTileWalkable();
    }
}
