﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class InputHandler : MonoBehaviour {

    public TileManager TileManager;
    public EventSystem EventsHandler;
    public GameManager GameManager;
    

    private bool bEditTilesModeActive = false;

    public void OnInputButtonChangedClicked()
    {
        if (bEditTilesModeActive)
        {
            bEditTilesModeActive = true;
            TileManager.TurnOffTileGUI();
        }
        else
        {
            bEditTilesModeActive = false;
            TileManager.TurnOnTileGUI();
        }
    }
	
	void Update ()
    {
        if (EventsHandler.IsPointerOverGameObject())
            return;

        if (Input.GetButtonDown("Fire1"))
        {
            if (bEditTilesModeActive == true)
            {
                TileManager.HandleInput();
            }
            else
            {
                TileManager.GenerateDjikstrasMap(GameManager.DebugLayer ,Camera.main.ScreenToWorldPoint(Input.mousePosition));
            }
        }
        
    }
}
