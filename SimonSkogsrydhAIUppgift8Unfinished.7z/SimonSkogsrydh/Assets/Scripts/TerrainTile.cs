﻿using Priority_Queue;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ETerrainTypes
{
    Grass,
    Road,
    Mountain,
    Swamp,
    MAX
}

public enum TileLayers
{
    BlueTeam,
    RedTeam
}

public struct TerrainData
{
    public Color TileColor;
    public float TileCost;
    public bool Blocked;
}

public struct TiredSolution
{
    public float Influence;
    public TerrainTile Tile;
}

public class TerrainTile : MonoBehaviour
{
    public TerrainData myTerrainData = new TerrainData();

    private List<TerrainTile> myConnections = new List<TerrainTile>();
    private List<float> myDjiktrasCosts = new List<float>();
    private Dictionary<TileLayers, float> myTeamInflunce = new Dictionary<TileLayers, float>();
    private UnityEngine.UI.Text myTextDebugger;

    public static Font FontType;

    private void Start()
    {
        myDjiktrasCosts.Add(0.0f);
        myTeamInflunce.Add(TileLayers.BlueTeam, 0.0f);
        myTeamInflunce.Add(TileLayers.RedTeam, 0.0f);
    }

    public GameObject DebuggerParent
    {
        set
        {
            GameObject TileCoster = new GameObject();
            TileCoster.transform.parent = value.transform;
            myTextDebugger = TileCoster.AddComponent<UnityEngine.UI.Text>();
            TileCoster.transform.position = transform.position;
            TileCoster.transform.localScale = Vector3.one;

            myTextDebugger.font = FontType;
            myTextDebugger.text = "-";
            myTextDebugger.color = Color.black;
            myTextDebugger.alignment = TextAnchor.MiddleCenter;
            myTextDebugger.fontSize = 7;
        }
    }

    private void SetDjikstrasCost(int aLayerIndex, float aCost)
    {
        myDjiktrasCosts[aLayerIndex] = aCost;
    }

    public void RefreshDebugCost(int aLayerIndex)
    {
        if (myTextDebugger == null)
            return;

        myTextDebugger.text = myDjiktrasCosts[aLayerIndex].ToString();
        if (myDjiktrasCosts[aLayerIndex] > 9999.0f)
        {
            myTextDebugger.text = "-";
        }
    }

    public void SetDebugInfluenceState(TileLayers aLayerToShow, bool aShowInflunceFlag)
    {
        if (aShowInflunceFlag)
        {
            ShowTeamInfluence(aLayerToShow);
        }
        else
        {
            SetTerrainData(myTerrainData);
        }
    }

    public void SetTerrainData(TerrainData aDataToSet)
    {
        myTerrainData = aDataToSet;
        GetComponent<SpriteRenderer>().color = myTerrainData.TileColor;
    }

    public void ShowTeamInfluence(TileLayers aTileLayer)
    {
        Color InfluenceColor = Color.red;
        if (aTileLayer == TileLayers.BlueTeam)
        {
            InfluenceColor = Color.blue;
        }

        InfluenceColor.a = myTeamInflunce[aTileLayer] / 15.0f;
        GetComponent<SpriteRenderer>().color = InfluenceColor;
    }

    public bool IsEndTile(int aLayerIndex)
    {
        return myDjiktrasCosts[aLayerIndex] <= 0.0f;
    }

    public void AddConnection(TerrainTile aTile)
    {
        myConnections.Add(aTile);
    }

    public void ResetTileCost(int aLayerIndex)
    {
        SetDjikstrasCost(aLayerIndex, 999999.0f);
    }

    public void UpdateConnectedTilesCost(int aLayerIndex, SimplePriorityQueue<TerrainTile> TilesToCheck)
    {
        float CurrentLayerCost = myDjiktrasCosts[aLayerIndex];
        foreach (TerrainTile Connection in myConnections)
        {
            float ConnectedTileCost = CurrentLayerCost + Connection.myTerrainData.TileCost;

            if (ConnectedTileCost < Connection.GetLayerCost(aLayerIndex))
            {
                Connection.SetCostForLayer(aLayerIndex, ConnectedTileCost);

                if (TilesToCheck.Contains(Connection))
                {
                    TilesToCheck.UpdatePriority(Connection, ConnectedTileCost);
                }
                else
                {
                    TilesToCheck.Enqueue(Connection, ConnectedTileCost);
                }
            }
        }
    }

    public void AddTeamInfluence(TileLayers aLayerToAddTo, float aInfluenceAmount, SimplePriorityQueue<TiredSolution> TilesToCheck, List<TerrainTile> aAssignedTiles)
    {
        if (aAssignedTiles.Contains(this) == false)
        {
            aAssignedTiles.Add(this);
        }

        myTeamInflunce[aLayerToAddTo] += aInfluenceAmount;

        float SpreadInfluence = aInfluenceAmount - 1.0f;
        if ((SpreadInfluence) > 0.0f)
        {
            List<TerrainTile> ConnectionsToSet = new List<TerrainTile>();
            foreach (TerrainTile Connection in myConnections)
            {
                if (aAssignedTiles.Contains(Connection) == false)
                {
                    aAssignedTiles.Add(Connection);

                    TiredSolution newData = new TiredSolution();
                    newData.Influence = SpreadInfluence;
                    newData.Tile = Connection;
                    TilesToCheck.Enqueue(newData, 5.0f - SpreadInfluence);
                }
            }
        }
    }

    public TerrainTile GetCheapestConnection(int aLayerIndex)
    {
        if (myConnections.Count < 1)
        {
            return this;
        }

        TerrainTile CheapestTile = myConnections[0];
        foreach (TerrainTile Connection in myConnections)
        {
            if (Connection.myDjiktrasCosts[aLayerIndex] < Connection.myDjiktrasCosts[aLayerIndex])
            {
                CheapestTile = Connection;
            }
        }

        return CheapestTile;
    }

    public List<TerrainTile> GetConnections()
    {
        return myConnections;
    }

    public float GetCost()
    {
        return myTerrainData.TileCost;
    }

    public bool IsTileWalkable()
    {
        return !myTerrainData.Blocked;
    }


    public float GetLayerCost(int aLayer)
    {
        return myDjiktrasCosts[aLayer];
    }

    public void SetCostForLayer(int aLayer, float aCost)
    {
        myDjiktrasCosts[aLayer] = aCost;
    }

    public void SetAsStartTile(int LayerIndex)
    {
        myDjiktrasCosts[LayerIndex] = 0.0f;
    }

    public void ResetTileInfluence()
    {
        myTeamInflunce[TileLayers.BlueTeam] = 0.0f;
        myTeamInflunce[TileLayers.RedTeam] = 0.0f;
    }
}
