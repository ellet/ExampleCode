﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum AITeams
{
    Blues,
    Reds,
    Neutral
}

public class FighterAI : MonoBehaviour
{
    public AITeams TeamAlliance;
    public GameObject ProjectilePrefab;
    static public float FighterMoveSpeed = 5.0f;
    static public float FighterHealth = 100.0f;
    static public float AggroRange = 10.0f;
    static public float FireRate = 0.2f;

    private ControllPoint myTargetControllPoint;
    private bool myHasDefenderToken = false;
    private float myHealth;
    private float myShootTimer;

    private float myAqcuireTargetTimer = 100.0f;

    public void TakeDamage(float aDamageAmount)
    {
        myHealth -= aDamageAmount;

        if (myHealth <= 0.0f)
        {
            Die();
        }
    }

    private void Start()
    {
        PollingStation.GetInstance().AddUnit(this);
        myHealth = FighterHealth;

        myShootTimer = FireRate;
    }

    private void Update()
    {
        AqcuireTargetControllPoint();

        if (myTargetControllPoint)
        {
            MoveTowardsTarget(myTargetControllPoint.transform.position);
        }
        else
        {
            MoveTowardsTarget(Vector2.zero);
        }

        myShootTimer += Time.deltaTime;
        if (myShootTimer > FireRate)
        {
            UpdateAggro();
        }
    }

    private void AqcuireTargetControllPoint()
    {
        if (myHasDefenderToken == true)
            return;

        myAqcuireTargetTimer += Time.deltaTime;
        if (myAqcuireTargetTimer < 2.5f)
            return;

        ControllPoint ClosestNeutralPoint = null;
        ControllPoint ClosestEnemyPoint = null;
        List<ControllPoint> ControllPoinsToCheck = PollingStation.GetInstance().ControllPoints;

        foreach(ControllPoint point in ControllPoinsToCheck)
        {
            switch (point.Allegiance)
            {
                case AITeams.Neutral:
                {
                    if (ClosestNeutralPoint == null)
                    {
                        ClosestNeutralPoint = point;
                    }
                    else
                    {
                        ClosestNeutralPoint = ClosestNeutralPoint.DetermineClosest(point, transform.position);
                    }
                }
                break;

                case AITeams.Blues:
                case AITeams.Reds:
                {
                    if (point.Allegiance == TeamAlliance)
                        continue;

                    if (ClosestEnemyPoint == null)
                    {
                        ClosestEnemyPoint = point;
                    }
                    else
                    {
                        ClosestEnemyPoint = ClosestEnemyPoint.DetermineClosest(point, transform.position);
                    }
                }
                break;
            }
        }

        if (ClosestNeutralPoint != null)
        {
            myTargetControllPoint = ClosestNeutralPoint;
            myAqcuireTargetTimer = 0.0f;
        }
        else if (ClosestEnemyPoint != null)
        {
            myTargetControllPoint = ClosestEnemyPoint;
            myAqcuireTargetTimer = 0.0f;
        }

        if (myTargetControllPoint != null)
        {
            myHasDefenderToken = myTargetControllPoint.AqcuireDefenderToken(TeamAlliance);
        }
    }

    private void MoveTowardsTarget(Vector2 TargetPosition)
    {
        Vector2 PositionDifference = TargetPosition - (Vector2)transform.position;

        if (PositionDifference.magnitude < 1.32f)
            return;

        Vector2 MoveDelta = PositionDifference.normalized * FighterMoveSpeed * Time.deltaTime;

        Vector3 newPosition = transform.position + (Vector3)MoveDelta;
        transform.position = newPosition;
    }

    private void UpdateAggro()
    {
        List<FighterAI> Enemies = PollingStation.GetInstance().GetOpposingTeam(TeamAlliance);

        FighterAI ClosestEnemy = null;
        float RangeToClossest = 99999.0f;
        foreach (FighterAI Fighter in Enemies)
        {
            float RangeToEnemy = (Fighter.transform.position - transform.position).magnitude;
            if (RangeToEnemy > AggroRange)
                continue;

            if (RangeToEnemy < RangeToClossest)
            {
                ClosestEnemy = Fighter;
                RangeToClossest = RangeToEnemy;
            }
        }

        if (ClosestEnemy != null)
        {
            AttackEnemy(ClosestEnemy);
        }
    }

    private void AttackEnemy(FighterAI aEnemyToAttack)
    {
        myShootTimer = 0.0f;
        Vector2 AttackDirection = (aEnemyToAttack.transform.position - transform.position).normalized;

        GameObject ProjectileObject = Instantiate(ProjectilePrefab, transform);
        Projectile NewProjectile = ProjectileObject.GetComponent<Projectile>();

        NewProjectile.Go(TeamAlliance, AttackDirection);
    }

    private void Die()
    {
        PollingStation.GetInstance().RemoveUnit(this);

        if (myHasDefenderToken == true)
        {
            myTargetControllPoint.ReturnDefenderToken(TeamAlliance);
        }

        Destroy(gameObject);
    }
}
