﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public float FightersStartHealth = 100.0f;
    public float FighterMoveSpeed = 5.0f;
    public UnityEngine.UI.Dropdown TileLayerDropdown;
    public TileManager TileManager;

    private int myControllDebugLayer = 0;
    private int myNumberOfControllPointLayers = 0;

    public void DjiktrasDebugLayerChanged()
    {
        TileManager.DebugLayer(TileLayerDropdown.value);
    }

    private void Start()
    {
        FighterAI.FighterHealth = FightersStartHealth;
        FighterAI.FighterMoveSpeed = FighterMoveSpeed;

        PollingStation.GetInstance().RegisterGameManager(this);
    }

    public void RegisterControllPointCount(int aControllPointCount)
    {
        TileLayerDropdown.options.Clear();

        int repeatCount = 0;
        while (repeatCount++ < aControllPointCount)
        {
            RegisterNewControllPointLayer();
        }
    }

    public int RegisterNewControllPointLayer()
    {
        ++myNumberOfControllPointLayers;

        UnityEngine.UI.Dropdown.OptionData newItem = new UnityEngine.UI.Dropdown.OptionData();

        newItem.text = (myNumberOfControllPointLayers - 1).ToString();

        TileLayerDropdown.options.Add(newItem);

        TileLayerDropdown.RefreshShownValue();

        return myNumberOfControllPointLayers;
    }

    public int DebugLayer
    {
        get
        {
            return myControllDebugLayer;
        }
    }

    private void LateUpdate()
    {
        TileManager.ResetInflunce();

        foreach (AITeams Team in System.Enum.GetValues(typeof(AITeams)))
        {
            if (Team == AITeams.Neutral)
                continue;

            List<FighterAI> TeamUnits = PollingStation.GetInstance().GetTeam(Team);

            foreach (FighterAI Fighter in TeamUnits)
            {
                TileManager.AddInfluence(Team, 5.0f, Fighter.transform.position);
            }
        }
    }
}
