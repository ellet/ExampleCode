﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllPoint : MonoBehaviour
{
    private int myLayerIndex = 0;
    private float myRadius = 4.5f;
    private AITeams myControlledByTeam = AITeams.Neutral;

    Dictionary<AITeams, int> myDefenderTokes = new Dictionary<AITeams, int>();

    public int LayerIndex
    {
        set
        {
            myLayerIndex = value;
        }

        get
        {
            return myLayerIndex;
        }
    }

    public AITeams Allegiance
    {
        get
        {
            return myControlledByTeam;
        }
    }

    public ControllPoint DetermineClosest(ControllPoint aControllPointToCheckAgaints, Vector2 aPositionToCheckTowards)
    {
        float DistanceToPoint = (aPositionToCheckTowards - (Vector2)transform.position).magnitude;
        float OtherDistanceToPoint = (aPositionToCheckTowards - (Vector2)aControllPointToCheckAgaints.transform.position).magnitude;

        if (DistanceToPoint < OtherDistanceToPoint)
        {
            return this;
        }
        else
        {
            return aControllPointToCheckAgaints;
        }
    }

	private void Start()
	{
		PollingStation.GetInstance().AddControllPoint(this);

        myDefenderTokes.Add(AITeams.Blues, 1);
        myDefenderTokes.Add(AITeams.Reds, 1);
    }

    public bool AqcuireDefenderToken(AITeams aTeamAllegiance)
    {
        if (myDefenderTokes[aTeamAllegiance] > 0)
        {
            myDefenderTokes[aTeamAllegiance] -= 1;
            return true;
        }

        return false;
    }

    public void ReturnDefenderToken(AITeams aTeamAllegiance)
    {
        myDefenderTokes[aTeamAllegiance] += 1;
    }

    private void Update()
    {
        int SurroundingUnitCount = 0;
        bool bSomePresence = false;

        List<FighterAI> BlueTeam = PollingStation.GetInstance().GetTeam(AITeams.Blues);
        foreach (FighterAI Bluei in BlueTeam)
        {
            float DistanceToDude = ((Vector2)Bluei.transform.position - (Vector2)transform.position).magnitude;

            if (DistanceToDude < myRadius)
            {
                bSomePresence = true;
                ++SurroundingUnitCount;
            }
        }

        List<FighterAI> RedTeam = PollingStation.GetInstance().GetTeam(AITeams.Reds);
        foreach (FighterAI Redi in RedTeam)
        {
            float DistanceToDude = ((Vector2)Redi.transform.position - (Vector2)transform.position).magnitude;

            if (DistanceToDude < myRadius)
            {
                bSomePresence = true;
                --SurroundingUnitCount;
            }
        }

        if (SurroundingUnitCount > 0)
        {
            SetAlligence(AITeams.Blues);
        }
        else if (SurroundingUnitCount < 0)
        {
            SetAlligence(AITeams.Reds);
        }
        else if (bSomePresence == true)
        {
            SetAlligence(AITeams.Neutral);
        }
    }

    private void SetAlligence(AITeams aControlledByTeam)
    {
        myControlledByTeam = aControlledByTeam;

        if (aControlledByTeam == AITeams.Blues)
        {
            GetComponent<SpriteRenderer>().color = Color.blue;
        }
        else if (aControlledByTeam == AITeams.Reds)
        {
            GetComponent<SpriteRenderer>().color = Color.red;
        }
        else
        {
            GetComponent<SpriteRenderer>().color = Color.white;
        }
    }
}
