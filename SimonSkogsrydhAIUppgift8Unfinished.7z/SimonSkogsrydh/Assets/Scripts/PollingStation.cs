﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PollingStation
{
    private Dictionary<AITeams, List<FighterAI>> myUnits;
    private List<ControllPoint> myControllPoints;
    private GameManager myGameManager;

    public void RegisterGameManager(GameManager aGameManager)
    {
        myGameManager = aGameManager;
        myGameManager.RegisterControllPointCount(myControllPoints.Count);
    }
    

    static private PollingStation ourInstance;
    static public PollingStation GetInstance()
    {
        if (ourInstance == null)
        {
            ourInstance = new PollingStation();
            ourInstance.Start();
        }

        return ourInstance;
    }

    public List<ControllPoint> ControllPoints
    {
        get
        {
            return myControllPoints;
        }
    }

    public void Start()
    {
        myUnits = new Dictionary<AITeams, List<FighterAI>>();
        myControllPoints = new List<ControllPoint>();

        myUnits.Add(AITeams.Blues, new List<FighterAI>());
        myUnits.Add(AITeams.Reds, new List<FighterAI>());
    }

    public void AddUnit(FighterAI Fighter)
    {
        List<FighterAI> Team = myUnits[Fighter.TeamAlliance];

        if (Team.Contains(Fighter) == false)
        {
            Team.Add(Fighter);
        }
    }

    public void RemoveUnit(FighterAI Fighter)
    {
        List<FighterAI> Team = myUnits[Fighter.TeamAlliance];

        if (Team.Contains(Fighter) == true)
        {
            Team.Remove(Fighter);
        }
    }

    public List<FighterAI> GetTeam(AITeams aTeamToGet)
    {
        return myUnits[aTeamToGet];
    }

    public List<FighterAI> GetOpposingTeam(AITeams aTeam)
    {
        if (aTeam == AITeams.Blues)
        {
            return myUnits[AITeams.Reds];
        }

        return myUnits[AITeams.Blues];
    }

    public void AddControllPoint(ControllPoint aControllPoint)
    {
        if (myControllPoints.Contains(aControllPoint) == false)
        {
            myControllPoints.Add(aControllPoint);
            aControllPoint.LayerIndex = myControllPoints.Count - 1;

            if (myGameManager != null)
            {
                myGameManager.RegisterNewControllPointLayer();
            }
        }
    }
}
