﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject ObjectToSpawn;
    public Vector2 Frequency = new Vector2(5, 10);

    private float SpawnTimer;

    private void Start()
    {
        SpawnTimer = 0.0f;
    }

    private void Update()
    {
        SpawnTimer -= Time.deltaTime;

        if (SpawnTimer <= 0.0f)
        {
            SpawnTimer = Random.Range(Frequency.x, Frequency.y);
            SpawnUnit();
        }
    }

    private void SpawnUnit()
    {
        Instantiate(ObjectToSpawn, transform.position, Quaternion.identity, transform);
    }
}
